module.exports = {
    'secretKey': 'cheqmateisawesometrustme2019' ,
    'domain':'http://localhost:3000/'   
};