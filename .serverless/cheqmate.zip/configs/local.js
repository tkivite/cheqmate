'use strict';
let localConfig = {
  hostname: 'localhost',
  port: 3000
};
module.exports = localConfig;