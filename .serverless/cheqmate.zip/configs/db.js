module.exports = { 
  'secret': 'putsomethingsecretehere',
  'database': 'mongodb://127.0.0.1:27017/formediumblog'
};